import React from 'react';

function Home(){
    return(
        <div align="center">
            <h1>ADO 2</h1>
            <span>ADO 2 de Programação Web.</span>
            <br/>
            
        </div>
    )
}
export default Home;