import React from 'react';

function Sobre(){
    return(
        <div>
            <h1>Bem vinda a Página: Sobre</h1>
            <span>Sobre nossa empresa</span>
            <br/>
             
        </div>
    )
}
export default Sobre;